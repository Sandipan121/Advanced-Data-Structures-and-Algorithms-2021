# 3D_ASCII_Earth
3D spinning ASCII Earth created using Python with Pygame.
YT tutorial link: https://www.youtube.com/watch?v=7Q6yvpjvKVg&t

There are 5 parts (next part includes all parts before):

- ascii_3d_earth_0_base.py
- ascii_3d_earth_1_object_projection.py
- ascii_3d_earth_2_rotation.py
- ascii_3d_earth_3_sphere.py
- ascii_3d_earth_4_ascii_earth.py

The full code you can find in ascii_3d_earth.py.
